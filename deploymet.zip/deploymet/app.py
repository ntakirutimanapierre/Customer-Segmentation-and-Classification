import os

# os.system('cls')

import joblib
import pandas as pd
from flask import Flask, render_template, request

# Load the logistic regression model
model = joblib.load('supervisedselectedfeatures\model_LogisticRegression.pkl')

# Load the StandardScaler object
with open('scaler.pkl', 'rb') as scaler_file:

    scaler = joblib.load(scaler_file)

app = Flask(__name__)
app.template_folder = os.path.abspath('templates')
app.static_folder = 'static'


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Get input data from the form
        input_data = request.form.to_dict()

        # Convert input data to a DataFrame
        new_customer_data = pd.DataFrame([input_data])

        new_customer_data_scaled = scaler.fit_transform(new_customer_data)

        prediction = model.predict(new_customer_data_scaled)
        
        predictions = f'This customer is predicted to be in category {prediction[0]}'
        

        # Display the result
        return render_template('result.html', prediction=predictions)


if __name__ == '__main__':
    app.run(debug=True)
